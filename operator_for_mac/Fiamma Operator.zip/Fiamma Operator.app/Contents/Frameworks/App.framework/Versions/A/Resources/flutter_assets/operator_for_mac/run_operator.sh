#!/bin/zsh

# Fiamma Operator Run Script
echo "==== Starting Fiamma Operator ===="

# Usage information
function show_usage {
  echo "Usage: $0 [options]"
  echo "Options:"
  echo "  -h, --help           : Show this help message"
  exit 1
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)
      show_usage
      ;;
    *)
      echo "Unknown option: $1"
      show_usage
      ;;
  esac
done

# Get the absolute path of the current directory
CURRENT_DIR=$(pwd)

# Create log directory (if it doesn't exist)
mkdir -p "$CURRENT_DIR/.logs/bitvm-operator"

# Get the parent directory path (equivalent to project_root() in the Rust code)
PARENT_DIR=$(cd "$CURRENT_DIR/.." && pwd)

# Set environment variables
# This is crucial: Instead of setting it to current directory, we need to set it to parent directory
# so that logs are correctly created in the current directory
export FIAMMA_MONO_CONFIG_PATH="$PARENT_DIR/operator_for_mac"

echo "Config path: $FIAMMA_MONO_CONFIG_PATH"
echo "Log directory (expected): $CURRENT_DIR/.logs"

# Run the operator with required parameters
echo "Starting fiamma-operator..."
cd "$CURRENT_DIR"  # Ensure we're in the correct directory
chmod +x $HOME/operator_for_mac/fiamma-operator
xattr -rd com.apple.quarantine $HOME/operator_for_mac/fiamma-operator
FIAMMA_MONO_CONFIG_PATH="$FIAMMA_MONO_CONFIG_PATH" $HOME/operator_for_mac/fiamma-operator &

# Capture the PID of the background process
OPERATOR_PID=$!

# Small delay to allow the process to start
sleep 3

# Check if the process is running
if ps -p $OPERATOR_PID > /dev/null; then
  echo "==== Fiamma Operator is running with PID $OPERATOR_PID ===="
  echo "Logs are being saved to: $CURRENT_DIR/.logs/bitvm-operator/"
  echo "To view logs: tail -f $CURRENT_DIR/.logs/bitvm-operator/bitvm-operator.$(date -u +%Y-%m-%d-%H).log"
else
  echo "Error: fiamma-operator failed to start."
  exit 1
fi