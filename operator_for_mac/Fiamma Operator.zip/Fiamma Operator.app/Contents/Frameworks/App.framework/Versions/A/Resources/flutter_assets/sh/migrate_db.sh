cd $HOME/operator_for_mac/dal
DATABASE_URL="postgres://admin:admin123@localhost:7433/bitvm-operator"
sqlx migrate run
cd $HOME/operator_for_mac