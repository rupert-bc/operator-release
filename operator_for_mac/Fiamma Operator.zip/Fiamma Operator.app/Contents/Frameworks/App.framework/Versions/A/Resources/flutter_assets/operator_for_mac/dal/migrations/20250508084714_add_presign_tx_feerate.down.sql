-- Add down migration script here
ALTER TABLE operator_pegout DROP COLUMN presign_tx_feerate;