docker run \
        --rm \
        -d \
        --name redis \
        --network fiamma-bitvm-network \
        -p 6379:6379 \
        redis:latest