#!/usr/bin/env bash
set -x
set -eo pipefail

echo "==== Fiamma Database Initialization Script (Colima Optimized) ===="

if ! [ -x "$(command -v psql)" ]; then
    echo >&2 "Error: psql is not installed."
    exit 1
fi

if ! [ -x "$(command -v sqlx)" ]; then
    echo >&2 "Error: sqlx is not installed."
    echo >&2 "Use:"
    echo >&2 " cargo install --version=0.8.3 sqlx-cli --no-default-features --features postgres"
    echo >&2 "to install it."
    exit 1
fi

NETWORK_NAME="fiamma-bitvm-network"
if ! docker network inspect $NETWORK_NAME >/dev/null 2>&1; then
    echo "Network $NETWORK_NAME does not exist. Creating..."
    docker network create $NETWORK_NAME
else
    echo "Network $NETWORK_NAME already exists. Doing nothing."
fi

pwd=$(pwd)

# Check if a custom user has been set, otherwise default to 'postgres'
DB_USER=${POSTGRES_USER:=admin}
# Check if a custom password has been set, otherwise default to 'password'
DB_PASSWORD="${POSTGRES_PASSWORD:=admin123}"
# Check if a custom database name has been set, otherwise default to 'bitvm-operator'
DB_NAME="${POSTGRES_DB:=bitvm-operator}"
# Check if a custom port has been set, otherwise default to '7433'
DB_PORT="${POSTGRES_PORT:=7433}"
# Check if a custom repl password has been set, otherwise default to 'repl123'
DB_REPL_PASSWORD="${POSTGRES_REPLICA_PASSWORD:=repl123}"

# Create named volumes for colima to avoid permission issues with local directory mounts
docker volume create bitvm_operator_pgdata || true
docker volume create archivelog || true
docker volume create data-backup || true

# Stop and remove existing container if it exists
if docker container ls -a --format '{{.Names}}' | grep -x bitvm_operator_db > /dev/null 2>&1; then
    echo "Removing existing database container..."
    docker stop bitvm_operator_db 2>/dev/null || true
    docker rm bitvm_operator_db 2>/dev/null || true
fi

if [[ -z "${SKIP_DOCKER}" ]]
then
    echo "Starting PostgreSQL container with optimized settings for colima..."
    
    docker run \
        --mount type=bind,source="${pwd}"/dal/scripts/main_postgresql.conf,target=/etc/postgresql/postgresql.conf \
        --mount type=bind,source="${pwd}"/dal/scripts/main_pg_hba.conf,target=/etc/postgresql/pg_hba.conf \
        -v bitvm_operator_pgdata:/var/lib/postgresql/data \
        -v archivelog:/archivelog \
        -v data-backup:/tmp/postgresslave \
        --net $NETWORK_NAME \
        --name bitvm_operator_db \
        -e POSTGRES_USER=${DB_USER} \
        -e POSTGRES_PASSWORD=${DB_PASSWORD} \
        -e POSTGRES_DB=${DB_NAME} \
        -p "${DB_PORT}":5432 \
        -d postgres \
        postgres -c config_file=/etc/postgresql/postgresql.conf
fi

export PGPASSWORD="${DB_PASSWORD}"
echo "Waiting for PostgreSQL to be ready..."
until psql -h "localhost" -U "${DB_USER}" -p "${DB_PORT}" -d "postgres" -c '\q'; do
    >&2 echo "Postgres is still unavailable - sleeping"
    sleep 1
done

>&2 echo "Postgres is up and running on port ${DB_PORT}!"

export DATABASE_URL=postgres://${DB_USER}:${DB_PASSWORD}@localhost:${DB_PORT}/${DB_NAME}
echo "Creating database: ${DB_NAME}"
sqlx database create

echo "Running database migrations..."
cd "${pwd}"/dal && sqlx migrate run

>&2 echo "Postgres has been migrated"

echo "Setting up replication user..."
psql -h "localhost" -U "${DB_USER}" -p "${DB_PORT}" -d "${DB_NAME}" -c "DROP ROLE IF EXISTS repl;" || true
psql -h "localhost" -U "${DB_USER}" -p "${DB_PORT}" -d "${DB_NAME}" -c "CREATE ROLE repl REPLICATION LOGIN ENCRYPTED PASSWORD '${DB_REPL_PASSWORD}';" || true

>&2 echo "Replication role repl has been created"

# Prepare backup directory inside container
# echo "Preparing backup directory..."
# docker exec bitvm_operator_db sh -c "rm -rf /tmp/postgresslave/* && mkdir -p /tmp/postgresslave" || true

echo "Running pg_basebackup..."
docker exec bitvm_operator_db sh -c "pg_basebackup -h bitvm_operator_db -U repl -p 5432 -F p -X s -P -R -D /tmp/postgresslave" || {
    echo "Warning: pg_basebackup failed, but main database setup is complete"
}

>&2 echo "pg_basebackup finished, ready to go!"

>&2 echo "Database initialization completed successfully!"
>&2 echo ""
>&2 echo "Database connection details:"
>&2 echo "  Host: localhost"
>&2 echo "  Port: ${DB_PORT}"
>&2 echo "  Database: ${DB_NAME}"
>&2 echo "  User: ${DB_USER}"
>&2 echo "  Connection URL: ${DATABASE_URL}" 
