cd $HOME/operator_for_mac
./run.sh
