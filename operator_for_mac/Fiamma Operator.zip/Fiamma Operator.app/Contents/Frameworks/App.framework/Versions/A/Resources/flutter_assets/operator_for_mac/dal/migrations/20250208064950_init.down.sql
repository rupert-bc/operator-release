-- Add down migration script here
DROP TABLE IF EXISTS operator_pegout;
DROP TABLE IF EXISTS operator_kickoff;
DROP TABLE IF EXISTS operator_pegin_tasks;
