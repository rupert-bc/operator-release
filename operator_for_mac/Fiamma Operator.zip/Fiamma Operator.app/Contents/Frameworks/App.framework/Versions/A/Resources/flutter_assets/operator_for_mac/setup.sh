#!/bin/zsh

# Fiamma Operator Setup Script
# This script handles the setup process for the Fiamma Operator

set -e  # Exit on error

echo "====================================================="
echo "     FIAMMA OPERATOR SETUP SCRIPT                    "
echo "====================================================="
echo ""

# Function for displaying usage information
function show_usage {
  echo "Usage: $0 [options]"
  echo "Options:"
  echo "  --skip-docker        : Skip Docker installation"
  echo "  --skip-dependencies  : Skip dependencies installation"
  echo "  --skip-redis         : Skip Redis setup"
  echo "  --skip-db            : Skip database initialization"
  echo "  -h, --help           : Show this help message"
  exit 1
}

# Parse command line arguments
SKIP_DOCKER=false
SKIP_DEPENDENCIES=false
SKIP_REDIS=false
SKIP_DB=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-docker)
      SKIP_DOCKER=true
      shift
      ;;
    --skip-dependencies)
      SKIP_DEPENDENCIES=true
      shift
      ;;
    --skip-redis)
      SKIP_REDIS=true
      shift
      ;;
    --skip-db)
      SKIP_DB=true
      shift
      ;;
    -h|--help)
      show_usage
      ;;
    *)
      echo "Unknown option: $1"
      show_usage
      ;;
  esac
done

# Get the absolute path of the current directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Make all scripts executable
echo "Making scripts executable..."
chmod +x install_dependencies.sh
chmod +x redis.sh
chmod +x run_operator.sh
chmod +x install_docker_mac.sh
chmod +x run.sh

# 1. Install Docker if needed
if [ "$SKIP_DOCKER" = false ]; then
  echo ""
  echo "===== STEP 1: Installing Docker ====="
  
  # Check if Docker is already installed
  if command -v docker >/dev/null 2>&1 && command -v colima >/dev/null 2>&1; then
    echo "Docker and colima are already installed. Checking if colima is running..."
    if colima status >/dev/null 2>&1; then
      echo "Colima is already running. Skipping installation."
    else
      echo "Starting colima..."
      colima start
    fi
  else
    echo "Installing lightweight Docker (colima)..."
    ./install_docker_mac.sh
    
    # Check if Docker started correctly
    if ! command -v docker >/dev/null 2>&1 || ! docker info >/dev/null 2>&1; then
      echo "Docker installation or startup appears to have issues."
      echo "Please check colima status with: colima status"
      echo "To restart colima, run: colima restart"
      echo "Then run this script again with --skip-docker flag."
      exit 1
    fi
  fi
else
  echo "Skipping Docker installation as requested."
fi

# Check if Docker is running
if ! docker info >/dev/null 2>&1; then
  echo "Error: Docker is not running."
  if command -v colima >/dev/null 2>&1; then
    echo "Detected colima installation. Trying to start colima..."
    colima start
    sleep 5
    if ! docker info >/dev/null 2>&1; then
      echo "Failed to start Docker with colima. Please check colima status manually:"
      echo "  colima status"
      echo "  colima start"
      exit 1
    fi
  else
    echo "Please start Docker and try again."
    exit 1
  fi
fi

# 2. Install Dependencies
if [ "$SKIP_DEPENDENCIES" = false ]; then
  echo ""
  echo "===== STEP 2: Installing Dependencies ====="
  ./install_dependencies.sh
else
  echo "Skipping dependencies installation as requested."
fi

# 3. Start Redis
if [ "$SKIP_REDIS" = false ]; then
  echo ""
  echo "===== STEP 3: Starting Redis ====="
  
  # Check if Redis container is already running
  if docker container ls --format '{{.Names}}' | grep -x redis > /dev/null 2>&1; then
    echo "Redis container is already running. Skipping Redis setup."
  else
    # Check if container exists but is not running
    if docker container ls -a --format '{{.Names}}' | grep -x redis > /dev/null 2>&1; then
      echo "Redis container exists but is not running. Starting it..."
      docker start redis
    else
      # Check if redis image exists
      if docker image ls redis:latest | grep redis > /dev/null 2>&1; then
        echo "Creating and starting Redis container from existing image..."
        docker run --name redis -p 6379:6379 -d redis:latest
        
        # Wait a moment for the container to start
        sleep 5
        echo "Redis container created and started."
      else
        echo "Redis image not found. Pulling and starting Redis..."
        docker run --name redis -p 6379:6379 -d redis:latest
      fi
    fi
  fi
else
  echo "Skipping Redis setup as requested."
fi

# 4. Start Database
if [ "$SKIP_DB" = false ]; then
  echo ""
  echo "===== STEP 4: Starting Database Services ====="
  
  # Check if database container is already running
  if docker container ls --format '{{.Names}}' | grep -x bitvm_operator_db > /dev/null 2>&1; then
    echo "Database container is already running. Skipping database setup."
  else
    # Check if container exists but is not running
    if docker container ls -a --format '{{.Names}}' | grep -x bitvm_operator_db > /dev/null 2>&1; then
      echo "Database container exists but is not running. Starting it..."
      docker start bitvm_operator_db
    else
      # Run colima-optimized database initialization
      echo "Running database initialization..."
      chmod +x ./dal/scripts/init_main_db_colima.sh
      ./dal/scripts/init_main_db_colima.sh
    fi
  fi
else
  echo "Skipping database initialization as requested."
fi

echo ""
echo "====================================================="
echo "     FIAMMA OPERATOR SETUP COMPLETED SUCCESSFULLY    "
echo "====================================================="
echo ""

# Check and kill existing fiamma-operator process if running
echo "Checking for existing fiamma-operator process..."
if pgrep -f "fiamma-operator" > /dev/null; then
  echo "Stopping existing fiamma-operator process..."
  pkill -9 -f "fiamma-operator" 2>/dev/null || true
  sleep 1
  echo "Process stopped."
fi

echo ""
echo "To start the operator, run: ./run.sh" 