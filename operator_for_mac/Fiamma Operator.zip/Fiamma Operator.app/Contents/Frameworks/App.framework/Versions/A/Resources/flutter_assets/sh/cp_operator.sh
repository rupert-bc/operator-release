echo $(pwd)
echo $HOME/operator_for_mac/
#cp -r operator_for_mac $HOME
#echo 'copy success'
export PATH="/Applications/Docker.app/Contents/Resources/bin:$PATH"
export PATH="/opt/homebrew/bin:$PATH"
export PATH="$HOME.cargo/bin:$PATH"
export PATH="/usr/local/bin:$PATH"
#which  dirname
#which  chmod
cd $HOME/operator_for_mac
./setup.sh