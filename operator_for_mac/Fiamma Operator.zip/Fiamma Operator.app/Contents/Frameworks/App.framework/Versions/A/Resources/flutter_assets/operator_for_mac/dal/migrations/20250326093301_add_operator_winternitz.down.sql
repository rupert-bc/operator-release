-- Add down migration script here
DROP TABLE operator_winternitz;