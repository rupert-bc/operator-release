#!/bin/zsh

# Fiamma Operator Dependencies Installation Script for macOS
echo "==== Starting Fiamma Operator Dependencies Installation ===="

# Function to check if a command is available
command_exists() {
  command -v "$1" &> /dev/null
}

# Function to source profile files
source_profile() {
  if [ -f ~/.zshrc ]; then
    source ~/.zshrc
  fi
}

# Install Homebrew if not already installed
if ! command_exists brew; then
  echo "Installing Homebrew..."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  
  # Add Homebrew to PATH
  if [[ -d /opt/homebrew/bin ]]; then
    echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zshrc
    eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [[ -d /usr/local/bin ]]; then
    echo 'eval "$(/usr/local/bin/brew shellenv)"' >> ~/.zshrc
    eval "$(/usr/local/bin/brew shellenv)"
  fi
  
  echo "Homebrew installed successfully!"
else
  echo "Homebrew is already installed."
fi

# 1. Install PostgreSQL 14
if command_exists psql && psql --version | grep -q "14."; then
  echo "PostgreSQL 14 is already installed."
else
  echo "Installing PostgreSQL 14..."
  brew install postgresql@14
  
  # Add PostgreSQL binaries to PATH
  echo 'export PATH="/usr/local/opt/postgresql@14/bin:$PATH"' >> ~/.zshrc
  export PATH="/usr/local/opt/postgresql@14/bin:$PATH"
fi

# Verify PostgreSQL installation
if command_exists psql; then
  echo "PostgreSQL client installed successfully!"
  psql --version
else
  echo "Failed to install PostgreSQL client. Please try manually."
fi

# 2. Install Rust and Cargo if not already installed
if ! command_exists rustc || ! command_exists cargo; then
  echo "Installing Rust and Cargo..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
  
  # Add Cargo binaries to PATH
  source "$HOME/.cargo/env"
  echo 'export PATH="$HOME/.cargo/bin:$PATH"' >> ~/.zshrc
  export PATH="$HOME/.cargo/bin:$PATH"
else
  echo "Rust and Cargo are already installed."
  rustc --version
  cargo --version
fi

# 3. Install SQLx CLI
if command_exists sqlx && sqlx --version | grep -q "v0.8.3"; then
  echo "SQLx CLI version v0.8.3 is already installed."
else
  echo "Installing SQLx CLI version v0.8.3..."
  cargo install --version=0.8.3 sqlx-cli --no-default-features --features postgres
fi

# Verify SQLx installation
if command_exists sqlx; then
  echo "SQLx CLI installed successfully!"
  sqlx --version
else
  echo "Failed to install SQLx CLI. Please try manually."
fi

# 4. Install Redis
if command_exists redis-cli; then
  echo "Redis client is already installed."
else
  echo "Installing Redis..."
  brew install redis
fi

# Verify Redis installation
if command_exists redis-cli; then
  echo "Redis client installed successfully!"
  redis-cli --version
else
  echo "Failed to install Redis client. Please try manually."
fi

# 5. Install Docker if not already installed
if command_exists docker && command_exists colima; then
  echo "Docker CLI and colima are already installed."
  # Check if colima is running
  if ! colima status &> /dev/null; then
    echo "Starting colima..."
    colima start
  fi
else
  echo "Installing lightweight Docker (Docker CLI + colima)..."
  brew install docker colima

  echo "Starting colima (lightweight Docker runtime)..."
  colima start
  
  echo "Waiting for colima to start..."
  sleep 5
  
  echo "NOTE: colima is a lightweight Docker runtime that provides Docker API compatibility"
fi

# Ensure all environment variables are applied
source_profile

echo "==== Dependency Installation Complete ===="
echo ""
echo "Installed components:"
echo "✓ PostgreSQL 14"
echo "✓ Rust and Cargo"
echo "✓ SQLx CLI (version 0.8.3)"
echo "✓ Redis"
echo "✓ Docker CLI + colima"
echo ""
echo "You may need to restart your terminal or run 'source ~/.zshrc' to apply all PATH changes."
echo "To start using Fiamma Operator, please refer to the README.md for next steps." 