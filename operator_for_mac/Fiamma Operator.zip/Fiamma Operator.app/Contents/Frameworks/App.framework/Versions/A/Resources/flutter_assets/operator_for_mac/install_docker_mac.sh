#!/bin/zsh

echo "==== Starting lightweight Docker installation script for macOS ===="
echo "This script will install Homebrew (if not present), Docker CLI, and colima"

# Check if Homebrew is installed
if ! command -v brew &> /dev/null; then
  echo "Homebrew not found. Installing Homebrew..."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  
  # Add Homebrew to PATH
  if [[ -d /opt/homebrew/bin ]]; then
    echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zshrc
    eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [[ -d /usr/local/bin ]]; then
    echo 'eval "$(/usr/local/bin/brew shellenv)"' >> ~/.zshrc
    eval "$(/usr/local/bin/brew shellenv)"
  fi
  
  echo "Homebrew installed successfully!"
else
  echo "Homebrew is already installed."
fi

# Install Docker CLI and colima
echo "Installing Docker CLI and colima..."
brew install docker colima

# Start colima
echo "Starting colima (lightweight Docker runtime)..."
colima start

# Wait for colima to start
echo "Waiting for colima to start..."
sleep 10

# Check if Docker is working
echo "Checking Docker installation..."
if ! command -v docker &> /dev/null; then
  echo "Docker CLI not found. Installation might have issues."
  exit 1
else
  echo "Docker CLI found. Checking Docker daemon connection..."
  if docker info &> /dev/null; then
    echo "==== Lightweight Docker installed and running successfully! ===="
    docker --version
    colima --version
  else
    echo "Docker daemon not responding. Trying to restart colima..."
    colima restart
    sleep 5
    if docker info &> /dev/null; then
      echo "==== Lightweight Docker installed and running successfully! ===="
      docker --version
      colima --version
    else
      echo "Docker daemon still not responding. Please check colima status with: colima status"
      exit 1
    fi
  fi
fi

echo "Installation process completed."
echo "Note: colima is a lightweight Docker runtime that provides Docker API compatibility"
echo "To stop: colima stop"
echo "To start: colima start"