# Fiamma Operator macOS Installation Scripts

This directory contains scripts for setting up the Fiamma Operator environment on macOS.

## Main Scripts

### Primary Scripts (User Interface)
- `setup.sh` - **Main setup script** that handles all installation and environment setup
- `run.sh` - **Main run script** that starts the Fiamma Operator

### Supporting Scripts (Called by main scripts)
- `install_docker_mac.sh` - Installs lightweight Docker (colima) for macOS
- `install_dependencies.sh` - Installs all required dependencies for Fiamma Operator  
- `redis.sh` - Sets up Redis in a Docker container
- `run_operator.sh` - Executes the Fiamma Operator binary

## Quick Start

### Step 1: Setup Environment

Run the setup script to install all dependencies and services:

```bash
chmod +x setup.sh
./setup.sh
```

The setup script executes all installation steps:
1. Install lightweight Docker (colima)
2. Install required dependencies (PostgreSQL 14, Rust, SQLx CLI, Redis client)
3. Start Redis service in Docker
4. Initialize PostgreSQL database

You can skip specific steps if already completed:

```bash
# Skip Docker installation
./setup.sh --skip-docker

# Skip dependencies installation
./setup.sh --skip-dependencies

# Skip Redis setup
./setup.sh --skip-redis

# Skip database initialization
./setup.sh --skip-db
```

You can run database migrations to set up the required database schema:

```bash
cd dal && cp .env.example .env && sqlx migrate run
```

### Step 2: Run the Operator

After setup is complete, start the operator:

```bash
chmod +x run.sh
./run.sh
```

The run script will start the Fiamma Operator and display logs in real-time.

## Prerequisites

- macOS operating system
- Administrator privileges (for installing software)
- Internet connection

## Installation Instructions (Manual)

If you prefer to run each step individually:

1. Make the scripts executable:
   ```bash
   chmod +x setup.sh run.sh
   ```

2. Run the setup script:
   ```bash
   ./setup.sh
   ```

3. Start the operator:
   ```bash
   ./run.sh
   ```

## What Gets Installed

The setup script installs the following components:

1. **Docker CLI + colima** - Lightweight containerization platform
2. **Homebrew** - Package manager for macOS (if not already installed)
3. **PostgreSQL 14** - Database client
4. **Rust and Cargo** - Programming language and package manager
5. **SQLx CLI (v0.8.3)** - Database management tool
6. **Redis** - In-memory data store client

The scripts check for existing installations and only install components that are not already present on your system.

## Service Ports

| Service          | Port  | Description            |
|-----------------|-------|------------------------|
| PostgreSQL      | 7433  | Database service      |
| Redis           | 6379  | Cache service         |

## Architecture

The script architecture is designed for simplicity and modularity:

```
setup.sh (Main setup script)
├── install_docker_mac.sh (Docker installation)
├── install_dependencies.sh (Dependencies installation)
├── redis.sh (Redis setup)
└── Database initialization

run.sh (Main run script)
└── run_operator.sh (Operator execution)
```

## Docker Implementation

The scripts use **colima** instead of Docker Desktop for a lightweight Docker experience:

- **Lightweight**: No GUI overhead, faster startup
- **Compatible**: Full Docker API compatibility
- **Efficient**: Lower resource usage compared to Docker Desktop

### Docker Commands:
- Start: `colima start`
- Stop: `colima stop`
- Status: `colima status`

## Troubleshooting

### General Issues
- If you encounter issues with Homebrew installations, try running `brew doctor` to diagnose problems
- For PATH-related issues, ensure you've sourced your shell configuration file with `source ~/.zshrc`
- To verify services are running, use `docker ps` to see active containers

### Docker Issues
- If colima fails to start, try `colima restart`
- Check colima status with `colima status`
- For permission issues with containers, the setup script will automatically recreate them

### Service Issues
- To view database logs: `docker logs bitvm_operator_db`
- To view Redis logs: `docker logs redis`
- To check container status: `docker container ls -a`

### Manual Recovery
If services fail to start automatically:

```bash
# Start colima manually
colima start

# Start containers manually
docker start redis
docker start bitvm_operator_db

# Check status
docker ps
```

## Advanced Usage

### Skip Options for setup.sh
- `--skip-docker`: Skip Docker installation
- `--skip-dependencies`: Skip dependencies installation
- `--skip-redis`: Skip Redis setup
- `--skip-db`: Skip database initialization
- `--help`: Show usage information

### Log Location
Operator logs are available at: `./.logs/bitvm-operator/bitvm-bridge.YYYY-MM-DD.log`

## Security Notes

The operator handles cryptographic operations and database access. Ensure your system is properly secured and up to date before running in production environments.