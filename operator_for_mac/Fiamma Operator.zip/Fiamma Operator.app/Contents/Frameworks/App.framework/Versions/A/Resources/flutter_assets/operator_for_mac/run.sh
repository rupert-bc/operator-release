#!/bin/zsh

# Fiamma Operator Run Script
# This script runs the Fiamma Operator

set -e  # Exit on error

echo "====================================================="
echo "     FIAMMA OPERATOR RUN SCRIPT                      "
echo "====================================================="
echo ""

# Function for displaying usage information
function show_usage {
  echo "Usage: $0 [options]"
  echo "Options:"
  echo "  -h, --help           : Show this help message"
  exit 1
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  case "$1" in
    -h|--help)
      show_usage
      ;;
    *)
      echo "Unknown option: $1"
      show_usage
      ;;
  esac
done

# Get the absolute path of the current directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Run the Operator
echo ""
echo "===== STEP 1: Starting Fiamma Operator ====="
"$HOME/operator_for_mac/run_operator.sh"

echo ""
echo "====================================================="
echo "     FIAMMA OPERATOR STARTED SUCCESSFULLY            "
echo "====================================================="