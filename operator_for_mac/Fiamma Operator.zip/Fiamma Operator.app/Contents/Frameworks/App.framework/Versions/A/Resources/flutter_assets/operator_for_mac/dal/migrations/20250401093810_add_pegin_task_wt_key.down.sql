-- Add down migration script here
ALTER TABLE operator_pegin_tasks DROP COLUMN wt_keys;
